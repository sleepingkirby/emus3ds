sdmc
=======

very simple example of how to access SD files with libctru;


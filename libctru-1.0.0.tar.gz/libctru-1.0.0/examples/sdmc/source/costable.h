#ifndef COSTABLE_H
#define COSTABLE_H

extern s32 costable[];

#endif

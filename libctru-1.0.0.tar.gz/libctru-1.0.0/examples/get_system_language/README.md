get_system_language
=======

This is an example on how to get the system language on the 3DS.

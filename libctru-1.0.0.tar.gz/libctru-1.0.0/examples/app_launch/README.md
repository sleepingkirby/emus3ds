app_launch
=======

Example for launching other apps/applets with ctrulib. Press the A button to launch the app or applet specified in the source.


Note: The title ID of the EUR Nintendo 3DS Camera app is hardcoded and you need to change it if your 3DS is not an european one. See here for title IDs: http://3dbrew.org/wiki/Title_list#00040010_-_System_Applications
This example only works if launched as regular app by the home menu. It will not work with the homebrew menu.


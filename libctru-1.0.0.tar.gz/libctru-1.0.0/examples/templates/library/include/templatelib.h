#ifndef _templatelib_h_
#define _templatelib_h_

int myLibFunction();

#endif // _templatelib_h_

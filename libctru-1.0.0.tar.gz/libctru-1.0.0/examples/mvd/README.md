This example is for using New3DS MVD, for hardware color-format conversion + video processing(the latter is not supported by ctrulib/this example yet).

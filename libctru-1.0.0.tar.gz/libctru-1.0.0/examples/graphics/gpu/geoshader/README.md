# GPU example

This is a simple GPU example using the `picasso` shader assembler which comes with devkitARM r45 and up.
Users of earlier versions of devkitARM need to install the tool, which can be found in the address below:

https://github.com/fincs/picasso/releases

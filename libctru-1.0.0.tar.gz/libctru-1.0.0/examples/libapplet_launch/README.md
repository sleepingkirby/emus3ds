libapplet_launch
=======

Example for launching library applets. This launches the extrapad library applet(Circle Pad Pro calibration applet) when the B button is pressed.

This is not usable from the homebrew launcher.

